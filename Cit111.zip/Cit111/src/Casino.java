class Casino {
static final Account ac = new Account();
static final Cards card = new Cards();
static CardRanks playerRank, computerRank;
static CardSuits playerSuit, computerSuit;
static int i =0;
public static void main(String[] args) throws InterruptedException {
HighLow.HighLow();
}}

